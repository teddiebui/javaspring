package com.example.demo10092021;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo10092021ApplicationTests {

	@Test
	void contextLoads() {
	}

}
